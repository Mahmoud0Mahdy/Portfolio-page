import { Component } from '@angular/core';

@Component({
  selector: 'app-impact-mena',
  standalone: true,
  imports: [],
  templateUrl: './impact-mena.component.html',
  styleUrl: './impact-mena.component.css'
})
export class ImpactMenaComponent {

}