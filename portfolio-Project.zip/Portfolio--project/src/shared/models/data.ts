//Screen size from 1200 to 1920 L
const large = window.matchMedia("(max-width: 1200px)");


//screen size from 
const mid = window.matchMedia("(max-width: 1200px)");

//screen size from 415 to 0
const small = window.matchMedia("(max-width: 415px)");

// // get form data
// function UserData (name:string, email:string, msg:string) {
//     this.name = name;
//     this.email = email;
//     this.msg = msg;
// } 
// var data = [];
 
// var hi = new UserData ("hi", "hi", "hi");

